/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.interpixel.siloproject;

import java.time.LocalDate;

/**
 *
 * @author Julius
 */
public class SuratJalan {
    public SuratPembelian sp;
    public String nomorSJ;
    public String namaCustomer;
    public String emailCustomer;
    public LocalDate tanggalOrder;
    public LocalDate tanggalSelesai;
    public String status;
}
