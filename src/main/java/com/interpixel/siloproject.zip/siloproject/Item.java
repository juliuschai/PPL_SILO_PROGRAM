/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.interpixel.siloproject;

/**
 *
 * @author Julius
 */
public class Item {
    public String id;
    public String barcode;
    public String judul;
    public String deskripsi;
    public String pemanufaktur;
    public int stock;
    public String url;
}
